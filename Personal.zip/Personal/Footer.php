<footer id="footer" class="footer dark-background">
    <div class="container">
      <h3 class="sitename">Personal</h3>
      <p style="font-style: normal;"> Passionate Full Stack Web Developer skilled in building responsive websites and web applications using modern technologies</p>
      <div class="social-links d-flex justify-content-center">
        
        <a href=""><i class="bi bi-instagram"></i></a>
        
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>
      <div class="container">
        <div class="copyright">
          <span>Copyright</span> <strong class="px-1 sitename">Personal</strong> <span>All Rights Reserved</span>
        </div>
        <div class="credits">
         
          Designed by Nitin Kumar
        </div>
      </div>
    </div>
  </footer>