<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name    = htmlspecialchars($_POST['name']);
    $email   = htmlspecialchars($_POST['email']);
    $subject = htmlspecialchars($_POST['subject']);
    $message = htmlspecialchars($_POST['message']);

    $mail = new PHPMailer(true);

    try {
        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'ns5766609@gmail.com'; // YOUR GMAIL
        $mail->Password   = 'YOUR_APP_PASSWORD_HERE'; // APP PASSWORD
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        // Email Settings
        $mail->setFrom('ns5766609@gmail.com', 'Portfolio Contact');
        $mail->addAddress('ns5766609@gmail.com'); // RECEIVER
        $mail->addReplyTo($email, $name);

        $mail->Subject = $subject;
        $mail->Body    =
            "Name: $name\n" .
            "Email: $email\n\n" .
            "Message:\n$message";

        $mail->send();

        echo "<script>alert('Message sent successfully!'); window.location.href='contact.php';</script>";

    } catch (Exception $e) {
        echo "<script>alert('Message failed. Try again later'); window.history.back();</script>";
    }
}
?>
